/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modellbahndcc;

/**
 *
 * @author Андрей Карпов
 */
import javax.swing.JFrame;
import modellbahndcc.Robot;
import modellbahndcc.RobotFrame;
import modellbahndcc.TestFrame;
import javax.swing.JFrame;

public class ModellBahnDCC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Количество сторон многоугольника
        final int COUNT = 10;
        // Длина стороны
        final int SIDE = 100;
 
        Robot robot = new Robot(200, 50);
        // Создаем замкнутую фигуру с количеством углов COUNT
        for (int i = 0; i < COUNT; i++) {
            robot.forward(SIDE);
            robot.setCourse(robot.getCourse() + 360 / COUNT);
        }
 
        // Создаем форму для отрисовки пути нашего робота
        RobotFrame rf = new RobotFrame(robot);
        rf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        rf.setVisible(true);
        
          javax.swing.SwingUtilities.invokeLater(new Runnable() {
               public void run() {
                    JFrame.setDefaultLookAndFeelDecorated(true);
                    TestFrame frame = new TestFrame();
                    frame.pack();
                    frame.setLocationRelativeTo(null);
                    frame.setVisible(true);
               }
          });
        
        
    }
   
    
    
}
