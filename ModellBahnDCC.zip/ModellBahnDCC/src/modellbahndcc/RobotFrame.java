/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modellbahndcc;

import modellbahndcc.Robot;
import javax.swing.JFrame;
import javax.swing.JButton;


/**
 *
 * @author Андрей Карпов
 */
public class RobotFrame extends JFrame {
        public RobotFrame(Robot robot) {
        // Устанавливаем заголовок окна
        
        setTitle("Robot Frame");
        // Добавляем компонент для рисования пути робота
        add(new RobotPathComponent(robot));
        // Устанавливаем размеры окна
        setBounds(200, 200, 700, 500);
    }
 
}
