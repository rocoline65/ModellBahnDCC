/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modellbahndcc;

import modellbahndcc.RobotFrame;
import javax.swing.JFrame;
import javax.swing.JButton;


/**
 *
 * @author Андрей Карпов
 */
public class RobotManager {
    private JButton btnOk = new JButton("OK");
    private JButton btnCancel = new JButton("Cancel");
    public static void main(String[] args) {
        // Количество сторон многоугольника
        final int COUNT = 12;
        // Длина стороны
        final int SIDE = 100;

        Robot robot = new Robot(200, 50);
        // Создаем замкнутую фигуру с количеством углов COUNT
        for (int i = 0; i < COUNT; i++) {
            robot.forward(SIDE);
            robot.setCourse(robot.getCourse() + 360 / COUNT);
        }
 
        // Создаем форму для отрисовки пути нашего робота
        RobotFrame rf = new RobotFrame(robot);
        rf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        rf.setVisible(true);
    }
    
}
